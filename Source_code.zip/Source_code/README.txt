
The current version of code covers all experiments reported in Figures 5-7 as well as hardware implementations of the considered approaches, which was used for Figure 7.


The code and README file for FPGA design could be found in folder Experiment_3/FPGA_hardware.


DEPENDENCIES for experiments to obtain classification accuracy:

Matlab 2018b or later
Matlab Deep Learning Toolbox
Matlab Optimization Toolbox
Matlab Communications Toolbox



HOW TO:
	In each folder the name of the main script is META_RUN. It runs the necessary scenarios and functions. 

Note that the datasets are not provided. They are accessible via http://persoal.citius.usc.es/manuel.fernandez.delgado/papers/jmlr/data.tar.gz. Please extract them into a folders “many_datasets” for each corresponding experiment.  
The folders include only 2 datasets in order to demonstrate that the code works. Note also, that in order to start experiment 3 one first need to do FPGA simulations and obtain possible size of the model for the given budget.

