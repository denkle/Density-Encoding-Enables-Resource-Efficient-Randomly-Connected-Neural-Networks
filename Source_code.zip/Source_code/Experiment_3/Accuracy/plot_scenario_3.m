

load('ELM_ACCURACY_current_bound_energy_fp.mat')
ACCURACY_elm=ACCURACY;

load('i_ELM_ACCURACY_current_bound_energy_thr_c_3.mat')



figure()
hold on; box on;
plot(0:0.1:1, 0:0.1:1, 'k', 'LineWidth', 2)
scatter(ACCURACY_elm,ACCURACY)


ylim([0.4,1.0])
xlim([0.4,1.0])

xlabel('Accuracy of the fixed point RVFL') 
ylabel('Accuracy of the proposed approach')
set(gca,'FontSize',18) 
