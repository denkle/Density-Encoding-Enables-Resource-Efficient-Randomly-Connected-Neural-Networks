load('i_ELM_VALID_bound_energi_current.mat')  % load the results of grid search

%load('elm_opt_param_bound_energi_part1.mat')
%elm_opt_param_bound_energi(:,1)=elm_opt_param_bound_energi(:,1)+1; % get matlab index from 1
load('i_elm_opt_param_bound_energi.mat')


LAMBDA=2.^(-10:5); % for ridge regression from Table III in the paper


for ix=1:size(i_elm_opt_param_bound_energi,1)
   
   i=i_elm_opt_param_bound_energi(ix,1);
 
    
   temp=VALID_iELM{1,i}; 
   temp=round(1000*temp)/1000;
   [~, ind]=max(temp(:));

   
   i_elm_opt_param_bound_energi(ix,3)=LAMBDA(ind);
    
end


save i_elm_opt_param_bound_energi i_elm_opt_param_bound_energi