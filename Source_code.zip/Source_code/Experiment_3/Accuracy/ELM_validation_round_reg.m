function [accuracy_m] = ELM_validation_round_reg(DATA, LAB, indices,  dim, lambda, thr_r)
%ELM_VALIDATION Summary of this function goes here
%   Detailed explanation goes here

%separate into training and testing
LAB=double(LAB);
ind=indices(1,:);
ind=ind(~isnan(ind));
DATA_tr= DATA(ind,:);
LAB_tr=LAB(ind);

ind=indices(2,:);
ind=ind(~isnan(ind));
DATA_ts=DATA(ind,:);
LAB_ts=LAB(ind);

simul=5; % make a number of independent runs
L=dim;

[tr,n]=size(DATA_tr); % parameters of data number of features and size
ts=size(DATA_ts,1); % We use full dataset for training

m=length(unique(LAB));%number of output units

accuracy=zeros(simul,1); % stores the result




for sim=1:simul % this loop performs all independt runs
    rng('shuffle')
    
    Y=single(full(ind2vec(LAB_tr',m))'); %output matrix for one-hot encoding

    
    
    B=0.1*(2*rand(1,L,'single')-1); %random bias for each node in interval [-0.1 0.1]
    W=2*rand(n,L,'single')-1 ; %random weight of units in interval [-1 1]
    
    H=DATA_tr*W; % the values of hidden neurons before activation function
    H=1./(1+exp( -1*H +repmat(B,[tr,1]) )); % sigmoid on adding a bias
    
    %Learn matrix from reservoir to the outpur  by linear regression
    %Wout=(pinv(H'*H + lambda*eye(L)) * H' *Y); %solving ridge regression by pseudo inverse matrix
    Wout=(pinv(H'*H + lambda*diag(var(H)) ) * H' *Y); %solving ridge regression by pseudo inverse matrix
    
    %rounding regression part
    Wout=round(thr_r*(Wout /max(abs(Wout(:))) ));
    
%    Yhat=H*Wout; % esimated output values for the training data
    
    
    %Testing
    H_ts=DATA_ts*W+repmat(B,[ts,1]); %
    H_ts=1./(1+exp((-1)*H_ts));
    %H_ts=tanh(H_ts);
        
    [~,Yn_hat_ts]=max((H_ts*Wout)'); % WTA on esimated output values for the testing data
    accuracy(sim,1)=mean(LAB_ts==Yn_hat_ts');    
    
end

accuracy_m=mean(accuracy);



end

