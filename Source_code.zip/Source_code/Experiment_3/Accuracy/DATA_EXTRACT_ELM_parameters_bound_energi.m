load('ELM_VALID_bound_energi_current.mat')  % load the results of grid search

%load('elm_opt_param_bound_energi_part1.mat')
%elm_opt_param_bound_energi(:,1)=elm_opt_param_bound_energi(:,1)+1; % get matlab index from 1
load('elm_opt_param_bound_energi.mat')


LAMBDA=2.^(-10:5); % for ridge regression from Table III in the paper


for ix=1:size(elm_opt_param_bound_energi,1)
   
   i=elm_opt_param_bound_energi(ix,1);
 
    
   temp=VALID_ELM{1,i}; 
   temp=round(1000*temp)/1000;
   [~, ind]=max(temp(:));

   
   elm_opt_param_bound_energi(ix,3)=LAMBDA(ind);
    
end


save elm_opt_param_bound_energi elm_opt_param_bound_energi