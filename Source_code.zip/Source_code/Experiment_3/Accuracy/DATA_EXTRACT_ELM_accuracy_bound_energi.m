

% get list of all datasets
folder='/many_datasets/data/';
folder=strcat(pwd,folder);
list = dir(folder);

data = cell(size(list,1),1);
% extract file names
for index = 1:size(list,1)
    nameC = list(index).name;
    [path,name,ext] = fileparts(nameC);
    data{index} = name;
end
clear('path','name','nameC','ext','list','index');

%Load (i)ELM parameters after validation
%load('elm_opt_param_bound_energi_part1.mat') % 1 is already added after saving lambda
%elm_opt_param_bound_energi(:,1)=elm_opt_param_bound_energi(:,1)+1; % get matlab index from 1
load('elm_opt_param_bound_energi.mat')


ACCURACY=zeros(1,size(data,1));


%for all datasets read features and cross-validation indeces
for ix = 1:size(elm_opt_param_bound_energi,1)
    
    i=elm_opt_param_bound_energi(ix,1);
    disp([ix,i])
    
    dim=elm_opt_param_bound_energi(ix,2); % optimal dimensionality
    lambda=elm_opt_param_bound_energi(ix,3); % optimal lambda
    thr_r=127; % rounding threshold

    
    isseparated=0; % used as boolean varaible to check for 
    file_to_load= [folder, '/' data{i,1}, '/', data{i,1}, '_R.dat'   ];
    if exist(file_to_load, 'file') == 2 % case of a complete dataset
        DATA=readtable( file_to_load );
        DATA=single(table2array(DATA));
        DATA(:,1)=[]; % get rid of ids
        LAB=DATA(:,end) +1; % get classes % get rid of 0 classes
        DATA(:,end)=[]; % get rid of classes
        DATA=normalize(DATA,1,'range'); % columnwise data normalization into range [0, 1]

        %[RES(i,1),RES(i,2)]=size(DATA);
        %RES(i,3)=length(unique(LAB));
        
        %VAR_dat(i,1)=min(LAB);
        
    elseif exist([folder, '/' data{i,1}, '/', data{i,1}, '_train' , '_R.dat'   ], 'file') == 2 %case with existing testing and training datasets
        disp('separated datasets')
        isseparated=1;
        %load train data
        DATA=readtable( [folder, '/' data{i,1}, '/', data{i,1}, '_train' , '_R.dat'   ] );
        DATA=single(table2array(DATA));
        DATA(:,1)=[]; % get rid of ids
        LAB=DATA(:,end)+1; % get classes % get rid of 0 classes
        DATA(:,end)=[]; % get rid of classes
        DATA=normalize(DATA,1,'range'); % columnwise data normalization into range [0, 1]

        %load test data
        DATA_ts=readtable( [folder, '/' data{i,1}, '/', data{i,1}, '_test' , '_R.dat'   ] );
        DATA_ts=single(table2array(DATA_ts));
        DATA_ts(:,1)=[]; % get rid of ids
        LAB_ts=DATA_ts(:,end)+1; % get classes
        DATA_ts(:,end)=[]; % get rid of classes
        DATA_ts=normalize(DATA_ts,1,'range'); % columnwise data normalization into range [0, 1]
        
        
        %VAR_dat(i,1)=min([LAB; LAB_ts]);
        
        
    end
    

    
    
    %indices=readtable( [folder,  data{i,1}, '/', 'conxuntos' , '.dat'   ], opts, 'TreatAsEmpty','N/A' );
    %indices=readtable( [folder,  data{i,1}, '/', 'conxuntos' , '.dat'   ], 'Delimiter',' ', 'FileType','text', 'TreatAsEmpty','N/A', 'ReadVariableNames', 0 );
    %indices=readtable( [folder,  data{i,1}, '/', 'conxuntos' , '.dat'   ], 'Delimiter',' ',  'ReadRowNames', false, 'ReadVariableNames', 0,  opts );    
    
%     %load indices
%     opts = detectImportOptions([folder,  data{i,1}, '/', 'conxuntos' , '.dat'   ]);
%     opts.DataLines=[1,Inf];
%     opts.ConsecutiveDelimitersRule='join';
%     %opts.ExtraColumnsRule='ignore';
%     indices=readtable( [folder,  data{i,1}, '/', 'conxuntos' , '.dat'   ], opts);
%      
%     indices=table2cell(indices);
%     indices_log=cellfun(@isempty,indices);
%     indices(indices_log==1)={nan};
%     indices_log=cellfun(@ischar,indices);
%     
%     dim=size(indices);
%     for ii=1:dim(1)
%         for ij=1:dim(2)
%             if indices_log(ii,ij)==1
%                 indices{ii,ij}=str2num(indices{ii,ij}); % string to double
%             end
%         end
%     end
%     indices=cell2mat(indices);  
%     indices=indices+1; % get rid of 0 indices
    
    %a=~isnan(indices); % to get not NaN indices
    
    %VAR(i,1)=size(indices,2);
    
    %load indices K-fold
    opts = detectImportOptions([folder,  data{i,1}, '/', 'conxuntos_kfold' , '.dat'   ]);
    opts.DataLines=[1,Inf];
    %opts.ConsecutiveDelimitersRule='join';
    %opts.ExtraColumnsRule='ignore';
    indices_kfold=readtable( [folder,  data{i,1}, '/', 'conxuntos_kfold' , '.dat'   ], opts);
    indices_kfold=table2cell(indices_kfold);
    
    
    indices_kfold_num=[];
    for ii=1:size(indices_kfold,1)
        temp=str2num(indices_kfold{ii,1})+1; % get rid of 0 indices
        indices_kfold_num(ii,1:length(temp))=temp; % write in the array
    end
    indices_kfold=indices_kfold_num;
    clear indices_kfold_num
    
    
   
    if isseparated==0
        
        ACCURACY(1,i)=ELM_accuracy_cross_val_round_reg(DATA, LAB, indices_kfold,  dim, lambda,thr_r);
        
    else
        
        ACCURACY(1,i)=ELM_accuracy_ts_round_reg(DATA, LAB, DATA_ts, LAB_ts,  dim, lambda,thr_r);

    end   
    
 
    %
    
    
end

save ELM_ACCURACY_current_bound_energy_fp ACCURACY

