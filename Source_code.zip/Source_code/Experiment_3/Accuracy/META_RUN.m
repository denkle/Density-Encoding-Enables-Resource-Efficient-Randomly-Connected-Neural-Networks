clear all

%FP RVFL bound energy
DATA_EXTRACT_ELM_search_bound_energi % hyperparameters search
clear all
DATA_EXTRACT_ELM_parameters_bound_energi % Extracts best parameters
clear all
DATA_EXTRACT_ELM_accuracy_bound_energi % uses hyperparameters to obtain accuracy

%RVFL with density based encoding bound energy
clear all
DATA_EXTRACT_iELM_search_bound_energi % hyperparameters search
clear all
DATA_EXTRACT_iELM_parameters_bound_energi % Extracts best parameters
clear all
DATA_EXTRACT_iELM_accuracy_bound_energi % uses hyperparameters to obtain accuracy

%Plot results
clear all
plot_scenario_3
