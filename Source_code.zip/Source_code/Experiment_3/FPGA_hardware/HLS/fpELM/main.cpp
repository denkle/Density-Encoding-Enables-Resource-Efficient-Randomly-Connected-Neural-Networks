
#include "main.h"

#include "hls_math.h"

// TOP-LEVEL MODULE
void fpElm(AXI_STREAM &input_stream, AXI_STREAM &output_stream) {

#pragma HLS INTERFACE axis port=input_stream
#pragma HLS INTERFACE axis port=output_stream
#pragma HLS INTERFACE s_axilite port=return


	float input[K] 	= { 0.0 };
	float hidden[N] = { 0.0 };
	float output[L] = { 0.0 };

	qtype hidden_q[N] = { 0.0 };
	qtype input_q[K] = { 0.0 };
	qtype output_q[K] = { 0.0 };

	read_stream<float, K>(input_stream, input);

	quantize<K>(input, input_q);

	input_to_hidden(input_q, hidden);
	// x*Wi + b
	quantize<N>(hidden, hidden_q);

	hidden_to_output(hidden_q, output);
	// sig(h)*Wo
	quantize<L>(output, output_q);

	write_stream<float, L>(output_stream, output);

}


void input_to_hidden(qtype input[K], float hidden[N]) {
	Input2Hidden1: for (int i = 0; i < N; i++) {
		hidden[i] = 0.0;

		Input2Hidden2: for (int j = 0; j < K; j++) {
			hidden[i] += (float) (input[j] * W_in[i][j]);
		}

		// Bias
		hidden[i] = 1 / (1 + hls::exp(-hidden[i] + (float) b[i]));
	}
}


void hidden_to_output(qtype hidden[N], float output[L]) {
	Hidden2Output1: for (int i = 0; i < L; i++) {
		output[i] = 0.0;

		Hidden2Output2: for (int j = 0; j < N; j++) {
			output[i] += (float) (hidden[j] * W_out[i][j]);
		}
	}
}

// quantization is simply a change of precision
template <int size>
void quantize(float not_quantized[size], qtype yes_quantized[size]) {
	for (int i = 0; i < size; i++)
		yes_quantized[i] = not_quantized[i];
}
