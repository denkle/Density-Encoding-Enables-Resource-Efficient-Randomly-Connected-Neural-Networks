
#include "main.h"

#include "hls_math.h"

// TOP-LEVEL MODULE
void elm(AXI_STREAM &input_stream, AXI_STREAM &output_stream) {

#pragma HLS INTERFACE axis port=input_stream
#pragma HLS INTERFACE axis port=output_stream
#pragma HLS INTERFACE s_axilite port=return

	float input[K], output[L];
	float hidden[N] = { 0.0 };

	read_stream<float, K>(input_stream, input);

	input_to_hidden(input, hidden);
	hidden_to_output(hidden, output);

	write_stream<float, L>(output_stream, output);
}


void input_to_hidden(float input[K], float hidden[N]) {
	Input2Hidden1: for (int i = 0; i < N; i++) {
		hidden[i] = 0.0;

		// dot product

		Input2Hidden2: for (int j = 0; j < K; j++) {
			hidden[i] += input[j] * W_in[i][j];
		}

		// Bias sigmoid
		hidden[i] = 1 / (1 + hls::exp(-hidden[i] + b[i]));
	}
}


void hidden_to_output(float hidden[N], float output[L]) {
	Hidden2Output1: for (int i = 0; i < L; i++) {
		output[i] = 0.0;

		// dot product
		Hidden2Output2: for (int j = 0; j < N; j++) {
			output[i] += hidden[j] * W_out[i][j];
		}
	}
}
