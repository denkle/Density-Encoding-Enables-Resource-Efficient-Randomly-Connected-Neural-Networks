
#include "main.h"

// TOP-LEVEL MODULE
void iElm(AXI_STREAM &input_stream, AXI_STREAM &output_stream) {

#pragma HLS INTERFACE axis port=input_stream
#pragma HLS INTERFACE axis port=output_stream
#pragma HLS INTERFACE s_axilite port=return


	float input[K], output[L];
	read_stream<float, K>(input_stream, input);

	ap_int<hidden_bits> hidden[N] = { 0 };
	int input_x[K] = { 0 };

	input_transform(input, input_x);
	input_to_hidden(input_x, hidden);
	hidden_to_output(hidden, output);

	write_stream<float, L>(output_stream, output);

}

void input_transform(float input[K], int input_x[K]) {
	for (int i = 0; i < K; i++)
		input_x[i] = hls::round(input[i] * N);
}

void input_to_hidden(int input[K], ap_int<hidden_bits> hidden[N]) {
	Input2Hidden1: for (int i = 0; i < K; i++) {

		// weight XOR ((currentPosition < quantizedValue) ? 1 : 0)
		Input2HiddenAlt: for (int j = 0; j < N; j++)
			hidden[j] += role_vectors[i][j] ^ ((int) (j < input[i]));
	}

	ClipLoop: for (int j = 0; j < N; j++)
		// NOTE alternative way would be to not compute this when above 2h + M +/- k
		hidden[j] = clip(2 * hidden[j] - K);
}


void hidden_to_output(ap_int<hidden_bits> hidden[N], float output[L]) {
	Hidden2Output1: for (int i = 0; i < L; i++) {
		output[i] = 0.0;

		Hidden2Output2: for (int j = 0; j < N; j++) {
			output[i] += hidden[j] * W_out[i][j];
		}
	}
}

int clip(int before) {
	// applies to hidden layer only, and introduces non-linearity
	if (before > klip)
		return klip;
	else if (before < -klip)
		return -klip;
	else
		return before;

}
