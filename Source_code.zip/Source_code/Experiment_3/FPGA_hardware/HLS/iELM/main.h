

#ifndef MAIN_H
#define MAIN_H



#include "ap_axi_sdata.h"
#include "hls_stream.h"

typedef ap_axiu<32,1,1,1> AXI_VALUE;
typedef hls::stream<AXI_VALUE> AXI_STREAM;


// stream functions
template<class T, int length> void read_stream(AXI_STREAM&, T[]);
template<class T, int length> void write_stream(AXI_STREAM&, T[]);
template<class T, int length>
void read_stream(AXI_STREAM &in, T value[length]) {

	union {T a; unsigned int b;} tmp;

	for (int i = 0; i < length; i++) {
		AXI_VALUE dataIn = in.read();

		tmp.b = dataIn.data;
		value[i] = tmp.a;

		if (dataIn.last) break;
	}
}
template<class T, int length>
void write_stream(AXI_STREAM &out, T value[length]) {
	union {T a; unsigned int b;} tmp;

	for (int i = 0; i < length; i++) {
		AXI_VALUE dataOut;

		tmp.a = value[i];
		dataOut.data = tmp.b;
		dataOut.user = (i == 0) ? 1 : 0;
		dataOut.last = (i == length - 1) ? 1 : 0;
		dataOut.keep = 0xf;
		dataOut.strb = 0xf;

		out.write(dataOut);
	}
}




#include "params.h"


void iElm(AXI_STREAM&, AXI_STREAM&);
void input_transform(float[K], int[K]);
void input_to_hidden(int[K], ap_int<hidden_bits>[N]);
void hidden_to_output(ap_int<hidden_bits>[N], float[L]);

int clip(int);



#endif
