

ACRONYMS:
	ELM:	Extreme Learning Machine
	fpELM: 	fixed-precision Extreme Learning Machine
	iELM:	integer Extreme Learning Machine

	NOTE: ELM (Extreme Learning Machine) is used internally interchangebly with RVFL (Random Vector Functional Link), for convenience, and they are functionally equivalent

FOLDERS:
	-	HLS					High Level Synthesis, C-Files containing implementations of ELM, fpELM, iELM, which can then be synthesized into IP Cores
	-	SYNTH 				Synthesis, contains a block diagram showing the different components of the hardware system, and the TCL script used to run the synthesis. The project files wree intenionally omitted due to their large size, can be provided upon request
	-	N-SEARCH			Optimal Architecture Parameter Search, contains a jupyter notebook (python script) that iteratively searches for the best parameter N (number of hidden neurons) according to specific crtieria for each dataset, as described in Scenario 3 in the article


DEPENDENCIES:

Python3
Jupyter (from Anaconda)
Python Packages: numpy, os, subprocess, matplotlib, pandas, time, re, fileinput, csv, tqdm

Vivado 2018.3 + Vivado HLS


HOW TO:
	The main script is in the N-SEARCH folder, ELM-N-parameter-search-jupyter-notebook.py, and it is meant to be run sequentially as a jupyter notebook, each block is commented describing its purpose and functionality

	However, the algorithm can be run using this command*:

		python3 "./N-SEARCH/ELM-N-parameter-search-jupyter-notebook.py"

	* not recommended, as it was meant to be run in a Jupyter environment, and assumes all dependencies have been installed, parameters and environment variables set accordingly as described in ELM-N-parameter-search-jupyter-notebook.py