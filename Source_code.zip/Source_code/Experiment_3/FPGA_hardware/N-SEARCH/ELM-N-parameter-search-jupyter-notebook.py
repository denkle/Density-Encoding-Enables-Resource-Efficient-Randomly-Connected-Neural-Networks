
## EXPORTED FROM A JUPYTER NOTEBOOK

# coding: utf-8

# In[1]:

# imports and reqs

import numpy as np
import os
import subprocess
import matplotlib.pyplot as plt
import pandas as pd
import time
import re
import fileinput
import csv
from tqdm import tqdm_notebook as tqdm


# In[2]:

## Helpers

# runs external command
def run_command(c):
    ret = subprocess.run(c.split(), shell=True, capture_output=True)
    if ret.returncode:
        raise Exception(ret.stderr)
    else:
        return str(ret.stdout, 'ISO-8859-1')

# times a given a function
tid = lambda: int(round(time.time() * 1000))
def chronos(func, args=None):
    t1 = tid()
    
    ret = -1
    if args:
        ret = func(*args)
    else:
        ret = func()
        
    t2 = tid()
    
    return t2 - t1


# In[3]:

# meta-data about datasets, inputs/outputs
meta = np.array([[8, 3], [6, 2], [6, 2], [14, 2], [31, 5], [262, 13], [59, 18], [4, 3], [4, 2], [16, 2], [4, 2], [9, 2], [9, 2], [30, 2], [33, 2], [9, 6], [6, 4], [21, 10], [21, 3], [6, 18], [36, 2], [16, 2], [60, 2], [11, 11], [42, 2], [9, 3], [15, 2], [35, 2], [34, 6], [10, 2], [7, 8], [8, 3], [8, 3], [9, 2], [28, 8], [9, 6], [3, 2], [3, 3], [13, 5], [12, 2], [12, 5], [12, 5], [19, 2], [100, 2], [25, 2], [9, 2], [18, 7], [33, 2], [4, 3], [7, 10], [4, 3], [16, 26], [90, 15], [100, 9], [56, 3], [18, 4], [10, 2], [5, 2], [50, 2], [57, 2], [60, 3], [6, 2], [6, 2], [6, 2], [21, 2], [166, 2], [166, 2], [8, 5], [41, 2], [25, 3], [25, 2], [32, 3], [62, 10], [72, 2], [10, 5], [22, 2], [16, 10], [8, 2], [7, 3], [7, 3], [7, 3], [7, 2], [7, 6], [12, 2], [64, 100], [64, 100], [64, 100], [8, 3], [17, 15], [20, 2], [7, 3], [256, 10], [35, 18], [57, 2], [22, 2], [44, 2], [14, 2], [24, 2], [13, 2], [18, 7], [36, 6], [9, 7], [18, 4], [27, 7], [60, 6], [5, 3], [21, 3], [9, 2], [3, 2], [29, 2], [20, 2], [6, 2], [6, 3], [24, 4], [21, 3], [40, 3], [13, 3], [11, 6], [11, 7], [8, 10], [16, 7]])

# In[4]:

## check path, configure it externally
# setx PATH "%PATH%;C:\Xilinx\Vivado\2018.3\bin;"
print(run_command('echo %PATH%'))


# In[5]:

## define folders

root_dir = 'C:\\Users\\USERNAME\\Desktop\\elm-stuff\\'
hls_dir = root_dir + 'hls-elm'
synth_dir = root_dir + 'elm-integration'
synth_lock_file = root_dir + 'elm-integration\\elm-integration.runs\\impl_1\\.vivado.end.rst'


# In[16]:

## weight generator
## this block modifies Cpp header files before they get compiled and synthesized in HLS

def generate_binary(dims):
    return np.random.choice([0, 1], dims)

def generate_int(minmax, dims):
    return np.random.randint(-minmax, minmax + 1, dims)

def cppfy(arr):
    return arr.tolist().__str__().replace('[', '{').replace(']', '}')
    
#     ??
def decppfy(arr):
    pass

def gimme_bin(*dims):
    return cppfy(generate_binary(dims))
    
def gimme_int(minmax, *dims):
    return cppfy(generate_int(minmax, dims))
    
def gimme_uniform(*dims):
    return cppfy(np.random.rand(*dims))
    
def gimme_normal(*dims):
    return cppfy(np.random.randn(*dims))

def generate_weights_iELM(K, N, L):
    # fixed precision bruh
    precision = 5
    klip = 3
    with fileinput.input(files=(hls_dir + '\\iELM\\params.h'), inplace=True) as f:
        for line in f:
            if fileinput.filelineno() == 8:
                print("#define		hidden_bits		1 + {}".format(int(np.ceil(np.log2(K+1)))))
            elif fileinput.filelineno() == 9:
                print("#define		precision 		{}".format(precision))
            elif fileinput.filelineno() == 10:
                print("#define		klip			{}".format(klip))
            elif fileinput.filelineno() == 13:
                print("const ap_uint<1> role_vectors[K][N] = {};".format(gimme_bin(K, N)))
            elif fileinput.filelineno() == 14:
                print("const ap_int<precision> W_out[L][N] = {};".format(gimme_int(2 ** (precision - 1), L, N)))
            else:
                print(line.strip())
    
def generate_weights_fpELM(K, N, L):
    # fixed precision bruh, decimal is computed
    precision_total = 8
    precision_int = 5
    with fileinput.input(files=(hls_dir + '\\fpELM\\params.h'), inplace=True) as f:
        for line in f:
            if fileinput.filelineno() == 7:
                print("#define precision 		{}".format(precision_total))
            elif fileinput.filelineno() == 8:
                print("#define precision_int	{}".format(precision_int))
            elif fileinput.filelineno() == 23:
                print("const qtype W_in[N][K] = {};".format(gimme_normal(N, K)))
            elif fileinput.filelineno() == 24:
                print("const qtype W_out[L][N] = {};".format(gimme_normal(L, N)))
            elif fileinput.filelineno() == 25:
                print("const qtype b[N] = {};".format(gimme_normal(N)))
            else:
                print(line.strip())


# In[17]:

## hls + synth + report

def read_latency(report_path):
    with open(report_path) as f:
        rpt = f.readlines()[31].replace(' ', '')
        m = re.findall('(\d+)', rpt)
        return float(m[1])
    
def read_power(report_path):
    with open(report_path) as f:
        rpt = f.readlines()[-8].replace(' ', '')
        m = re.findall('([0-9]+[.][0-9]+)', rpt)
        return float(m[0])

def run_hls(K, N, L, typ):
    if typ not in ['iELM', 'fpELM']:
        raise Exception("UNDEFINED TYPE")

    run_command(f'cd {hls_dir} && vivado_hls -f {hls_dir}\\{typ}\\hls.tcl "K{K} N{N} L{L}"')
    
    return 0

def run_synth(typ):
    if typ not in ['iELM', 'fpELM']:
        raise Exception("UNDEFINED TYPE")
    
    # creates 4 jobs
    run_command(f'cd {synth_dir} && vivado -mode batch -source synth.tcl')
    
    # wait for .vivado.end.rst to be created
    while not os.path.exists(synth_lock_file):
        time.sleep(1)
    
    # hope for the best :x
    return 0

config = {
    'ielm': {
        'generator': lambda K, N, L: generate_weights_iELM(K, N, L),
        'magic_hls': lambda K, N, L: run_hls(K, N, L, 'iELM'),
        'magic_synth': lambda: run_synth('iELM'),
        'latency': lambda: read_latency(hls_dir + '\\iELM\\iELM\\syn\\report\\iElm_csynth.rpt'),
        'power': lambda: read_power(synth_dir + '\\elm-integration.runs\\impl_1\\ielm_wrapper_power_routed.rpt'),
    },
    'fpelm': {
        'generator': lambda K, N, L: generate_weights_fpELM(K, N, L),
        'magic_hls': lambda K, N, L: run_hls(K, N, L, 'fpELM'),
        'magic_synth': lambda: run_synth('fpELM'),
        'latency': lambda: read_latency(hls_dir + '\\fpELM\\fpELM\\syn\\report\\fpElm_csynth.rpt'),
        'power': lambda: read_power(synth_dir + '\\elm-integration.runs\\impl_1\\fpelm_wrapper_power_routed.rpt'),
    },
}

# ALL THE MAGIC
## run synthesis, and parse reports
def magic(typ, K, N, L, log=False):
    # synthesize
    config[typ]['generator'](K, N, L)
    t_hls = chronos(config[typ]['magic_hls'], (K, N, L))
    t_synth = chronos(config[typ]['magic_synth'])

    print(f'{(t_hls + t_synth) / 1000.0} s')
    
    # read reports
    P = config['ielm']['power']()
    dT = config['ielm']['latency']()
    freq = 1e8
    
    E = P * dT / freq
    
    if log:
        pass

    return E
    


# In[18]:

## typical params 

K = 16
N = 128
L = 4

## ENERGY BUDGET
# iELM: K = 16, N = 128, L = 4
E0 = 3.20e-6


# In[14]:

## iELM test
## This block is only meant to verify that the sythesis pipeline works properly

# synth
generate_weights_iELM(K, N, L)
chronos(config['ielm']['magic_hls'], (K, N, L))
chronos(config['ielm']['magic_synth'])

# read reports
P = config['ielm']['power']()
dT = config['ielm']['latency']()
freq = 1e8

# compute energy
E = P * dT / freq
print(f'{E*1e6:5.5f} uJ')


# In[19]:

# sort architectures by complexity (n_inputs + n_outputs)

complexity = np.sum(meta, axis=1)
sorted_idx = np.argsort(complexity)


# In[25]:

## PSEUDO-CODE SEARCH, using binary search

# PSEUDO
# 1. read K and L
# 2. input Nmax, Nmin 
# 3. input E0
# 4. search for a good N
#    a. N = Ceil((Nmax + Nmin) / 2)
#    b. SYNTHESIZE...
#    c. compute energy E  = Power x Latency / Frequency
#    d. E > E0 ?
#       OUI : Nmax = N
#       NON : Nmin = N
#    e. Nmax = Nmin + 1 ?
#       OUI : goto 5
#       NON : goto 4a
# 5. Train for Nmin


# bounds
Nmin = 1
Nmax = 442 + 1
E0 = 3.20e-6
N = -1

# 'ielm' or 'fpelm'
typ = 'ielm' 

# iterate across all datasets
for i in tqdm(range(meta.shape[0])):
    
    K, L = meta[sorted_idx[i]]
    Eoptimal = E0
    
    print(f'############################\n\n  +++ {i + 1} / 121')
    N = -1
    itr = 0
    while True:
        itr = itr + 1
        
        N = int(np.ceil((Nmax + Nmin) / 2))

        print('-------------------------')
        print(f'itr  : {itr}')
        print(f'K    : {K}')
        print(f'L    : {L}')
        print(f'Nmin : {Nmin}')
        print(f'Nmax : {Nmax}')
        print(f'N    : {N}')

        E = magic(typ, K, N, L)

        print(f'> E  : {E*1e6:5.5f} uJ')

        if E > E0:
            Nmax = N
        else:
            Nmin = N
            Eoptimal = E

        
        # save all results
        with open('all_ielm.csv', 'a') as csv_file:
            writer = csv.writer(csv_file, delimiter=',')
            
            P = config[typ]['power']()
            dT = config[typ]['latency']()
            
            writer.writerow([K, N, L, E, P, dT])
            
        if Nmax == Nmin + 1:
            if E > E0:
                N = Nmin
                
            break        
            
        
    print(' - END \n')
    print(f'N    : {N}')
    
    # save N
    with open('optimal_ielm.csv', 'a') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow([K, N, L, Eoptimal])
        
    # search window, based on previous results
    window = 128
    Nmin = (N - window, 1)[N <= window]
    Nmax = (N + window, 443)[N >= 443 - window]
