load('i_ELM_VALID_current.mat')



i_elm_opt_param=zeros(length(VALID_iELM),3); % will store found parameters

for i=1:length(VALID_iELM)
   %%
   temp=VALID_iELM{1,i}; 
   temp=round(1000*temp)/1000; % round accuracies
   max_acc=max(temp(:));
   
   ind=find(temp==max_acc);
   param = zeros(length(ind),3);  
   for j=1:length(ind)
       resid=mod(ind(j),length(DIM)); % row position 
       if resid==0
          resid=length(DIM); % 0 is not a valid index
       end
       col2= 1 +  ( ind(j) - resid  )/length(DIM); % column + width       
      
       col= mod(col2,length(LAMBDA));
       if col==0
          col=length(LAMBDA); % 0 is not a valid index
       end       
       width= 1 +  ( col2 - col  )/length(LAMBDA); % column + width       
 
       %disp(isequal((temp(resid,col,width)),max_acc ))
       param(j,:)= [DIM(resid), LAMBDA(col), THR(width)];  
            
   end
    
   %%
   min_dim=min(param(:,1));
   param=param(param(:,1)==min_dim,:);
   min_thr=min(param(:,3));
   param=param(param(:,3)==min_thr,:);   
   
   [~,min_lam]=min(param(:,2));
   param=param(min_lam,:); 
   
   
   %%
   i_elm_opt_param(i,:)=param;
   
   
end


save i_elm_opt_param i_elm_opt_param