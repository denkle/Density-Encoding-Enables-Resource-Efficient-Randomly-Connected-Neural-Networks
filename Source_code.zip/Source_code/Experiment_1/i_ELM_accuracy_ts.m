function [accuracy_m] = i_ELM_accuracy_ts(DATA, LAB, DATA_ts, LAB_ts,  dim, lambda, thr_c)
%ELM_VALIDATION Summary of this function goes here
%   Detailed explanation goes here


%quantize data for stochastic computing
L=dim; % number of hidden neurons

DATA=round(L*DATA)+1; % the lowest level would be 0 the highest L  % data with indices from 1 to N+1
DATA_ts=round(L*DATA_ts)+1; % the lowest level would be 0 the highest L  % data with indices from 1 to N+1

%separate into training and testing
LAB=double(LAB);


simul=5; % make a number of independent runs


[tr,n]=size(DATA); % parameters of data number of features and size
ts=size(DATA_ts,1); % We use full dataset for training

m=length(unique(LAB));%number of output units
isbinary=0; %defines whether to binarize or use clipping


accuracy=zeros(simul,1); % stores the result
FILL=[zeros(1,L,'int8');  tril(ones(L,'int8'))]; % all representations of levels from 1 to L+1




for sim=1:simul % this loop performs all independt runs
    rng('shuffle')
    
    Y=single(full(ind2vec(LAB',m))'); %output matrix for one-hot encoding
    
    Wb= randi([0,1],n,L,'int8'); % binary mask
%    W=2*round(rand(n,L))-1; % bipolar ROLE matrix instead of random projection matrix
    %%PROJECTION OF TRAINING DATA
    
    H=zeros(tr,L,'single'); % will store all training data
    % go through all examples
    for i=1:tr
        
        h=sum(2*single(xor(Wb,FILL(DATA(i,:),:)))-1,1); % % make binding  & superposition of all features
    
        %check what non-linearity to use
        if isbinary==1
            h=single(2*(h>0)-1); % binarize and bipolarize
        else
            %clipping
            h(h>thr_c)=thr_c;
            h(h<-thr_c)=-thr_c;
        end      
        
        H(i,:)=h; % update the collection     
    end 
    
    
    %%READ-OUT MATRIX
    %Learn matrix from reservoir to the outpur  by linear regression
    %Wout=(pinv(H'*H + lambda*eye(L)) * H' *Y); %solving ridge regression by pseudo inverse matrix
    Wout=(pinv(H'*H + lambda*diag(var(H)) ) * H' *Y); %solving ridge regression by pseudo inverse matrix
    
    %%PROJECTION OF TESTING DATA  
    
    H_ts=zeros(ts,L); % will store all test data
    % go through all examples in test data
    for i=1:ts

        h=sum(2*single(xor(Wb,FILL(DATA_ts(i,:),:)))-1,1); % % make binding  & superposition of all features

        
        %check what non-linearity to use
        if isbinary==1
            h=single(2*(h>0)-1); % binarize and bipolarize
        else
            %clipping
            h(h>thr_c)=thr_c;
            h(h<-thr_c)=-thr_c;
        end
        
        H_ts(i,:)=h; % update the collection
    end
        
    
    %%PREDICTIONS
    %Testing
        
    [~,Yn_hat_ts]=max((H_ts*Wout)'); % WTA on esimated output values for the testing data
    accuracy(sim,1)=mean(LAB_ts==Yn_hat_ts');    
    
end

accuracy_m=mean(accuracy);



end

