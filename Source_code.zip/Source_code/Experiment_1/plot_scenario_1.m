

load('ELM_ACCURACY_current.mat')
ACCURACY_elm=ACCURACY;

load('i_ELM_ACCURACY_current.mat')



figure()
hold on; box on;
plot(0:0.1:1, 0:0.1:1, 'k', 'LineWidth', 2)
scatter(ACCURACY_elm,ACCURACY)


ylim([0.5,1.0])
xlim([0.5,1.0])

xlabel('Accuracy of the conventional RVFL') 
ylabel('Accuracy of the proposed approach')
set(gca,'FontSize',18) 

