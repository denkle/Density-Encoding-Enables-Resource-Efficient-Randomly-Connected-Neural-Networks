load('ELM_VALID_current.mat') % load the results of grid search


elm_opt_param=zeros(121,2); % will store found parameters

for i=1:length(VALID)
   temp=VALID{1,i}; 
   temp=round(1000*temp)/1000;
   max_acc=max(temp(:));
   
   ind=find(temp==max_acc);
   param = zeros(length(ind),2);  
   for j=1:length(ind)
       resid=mod(ind(j),length(DIM)); % row position 
       if resid==0
          resid=length(DIM); % 0 is not a valid index
       end

       col= 1 +  ( ind(j) - resid  )/length(DIM); % column        
       param(j,:)= [DIM(resid), LAMBDA(col)];  
            
   end

   min_dim=min(param(:,1));
   param=param(param(:,1)==min_dim,:);
   [~,min_lam]=min(param(:,2));
   param=param(min_lam,:); 
   
   elm_opt_param(i,:)=param;
    
end


save elm_opt_param elm_opt_param