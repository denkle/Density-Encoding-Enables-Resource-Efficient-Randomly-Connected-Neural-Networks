function [accuracy_cv_m] = i_ELM_accuracy_cross_val_ga_no_ini(DATA, LAB, indices_kfold,  dim, lambda, thr_c, thr_r)
%ELM_VALIDATION Summary of this function goes here
%   Detailed explanation goes here


%quantize data for stochastic computing
L=dim; % number of hidden neurons

DATA=round(L*DATA)+1; % the lowest level would be 0 the highest L  % data with indices from 1 to N+1

%separate into training and testing
LAB=double(LAB);
accuracy_cv=zeros(4,1); % stores the result
simul=5; % make a number of independent runs
isbinary=0; %defines whether to binarize or use clipping


for f=1:4
    
    
    
    ind=indices_kfold(2*f-1,:);
    DATA_tr= DATA(ind,:);
    LAB_tr=LAB(ind);
    
    ind=indices_kfold(2*f,:);
    ind=ind(ind>0);
    DATA_ts=DATA(ind,:);
    LAB_ts=LAB(ind);
    

    
    
    [tr,n]=size(DATA_tr); % parameters of data number of features and size
    ts=size(DATA_ts,1); % We use full dataset for training
    
    m=length(unique(LAB));%number of output units
    nvars=L*m; % number of variables for GA
    
    
    accuracy=zeros(simul,1); % stores the result
    FILL=[zeros(1,L,'int8');  tril(ones(L,'int8'))]; % all representations of levels from 1 to L+1
    
    
    
    
    for sim=1:simul % this loop performs all independt runs
        rng('shuffle')
        
        Y=single(full(ind2vec(LAB_tr',m))'); %output matrix for one-hot encoding
        
        Wb= randi([0,1],n,L,'int8'); % binary mask
        %    W=2*round(rand(n,L))-1; % bipolar ROLE matrix instead of random projection matrix
        %%PROJECTION OF TRAINING DATA
        
        H=zeros(tr,L,'single'); % will store all training data
        Hn=zeros(tr,L,'single'); % will store all normalized data
        
        % go through all examples
        for i=1:tr
            
            h=sum(2*single(xor(Wb,FILL(DATA_tr(i,:),:)))-1,1); % % make binding  & superposition of all features
            
            %check what non-linearity to use
            if isbinary==1
                h=single(2*(h>0)-1); % binarize and bipolarize
            else
                %clipping
                h(h>thr_c)=thr_c;
                h(h<-thr_c)=-thr_c;
            end
            
            H(i,:)=h; % update the collection
            Hn(i,:)=h/norm(h);%normalize H for purity of experiment
            
        end
        
        
        %%READ-OUT MATRIX
        %Learn matrix from reservoir to the outpur  by linear regression
        %Wout=(pinv(H'*H + lambda*eye(L)) * H' *Y); %solving ridge regression by pseudo inverse matrix
        %Wout=(pinv(H'*H + lambda*diag(var(H)) ) * H' *Y); %solving ridge regression by pseudo inverse matrix
        
        %rounding regression part
        %Wout=round(thr_r*(Wout /max(abs(Wout(:)))  ));
        
        
        opts = optimoptions('ga');
        opts.MaxStallGenerations=100;
        %opts.InitialPopulationMatrix=double(Wout(:)');
        %opts.InitialPopulationMatrix=Woutga(:)';
        %opts.InitialPopulationMatrix=[Woutga(:)'; Wout(:)'];
        
        myCostFunc = @(x) costfcn(x,Hn,logical(Y'));
        [x,~,~] = ga(myCostFunc,nvars,[],[],[],[],-thr_r*ones(nvars,1),thr_r*ones(nvars,1),[],[1:nvars],opts);
        
        
        %Woutga=vec2mat(2*x-1,L)'; % make bipolar and convert to readout martrix
        Wout=vec2mat(x,L)'; % make bipolar and convert to readout martrix
        
        
        %disp([min(Wout(:)),max(Wout(:))])
        
        %%PROJECTION OF TESTING DATA
        
        H_ts=zeros(ts,L); % will store all test data
        % go through all examples in test data
        for i=1:ts
            
            h=sum(2*single(xor(Wb,FILL(DATA_ts(i,:),:)))-1,1); % % make binding  & superposition of all features
            
            
            %check what non-linearity to use
            if isbinary==1
                h=single(2*(h>0)-1); % binarize and bipolarize
            else
                %clipping
                h(h>thr_c)=thr_c;
                h(h<-thr_c)=-thr_c;
            end
            
            H_ts(i,:)=h; % update the collection
        end
        
        
        %%PREDICTIONS
        %Testing
        
        [~,Yn_hat_ts]=max((H_ts*Wout)'); % WTA on esimated output values for the testing data
        accuracy(sim,1)=mean(LAB_ts==Yn_hat_ts');
        
    end
    
    accuracy_m=mean(accuracy);
    
    accuracy_cv(f,1)=accuracy_m;
    
end


accuracy_cv_m=mean(accuracy_cv);

end

