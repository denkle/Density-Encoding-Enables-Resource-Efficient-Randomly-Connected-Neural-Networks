function [cost] = costfcn(x, Hn, Y)

%global Hn Y

L=size(Hn,2);

%R=single(vec2mat(2*x-1,L)'); % make bipolar and convert to readout martrix
R=vec2mat(x,L)'; % make bipolar and convert to readout martrix
R=R./sqrt(sum(R.^2,1)); % normalize readout 




DP=(1-Hn*R)'; % cosine similarity plus %invert cosine to distance
%DP=1-DP; 

% d_plus=zeros(size(DP,1),1); % stores correct distances
% for i=1:size(DP,1)
%    d_plus(i,1)=DP(i,Yn(i)); 
%    DP(i,Yn(i))=2; % set to very distance to find min then 
% end


d_plus=DP(Y); % stores correct distances
DP(Y)=2; % set to very distance to find min then 

d_minus= min(DP)'; % stores highest  incorrect distances

cost=200*(d_plus-d_minus)./(d_plus+d_minus);
cost=sum(1./(1+exp(-cost)));
%cost=sum(cost);


end

