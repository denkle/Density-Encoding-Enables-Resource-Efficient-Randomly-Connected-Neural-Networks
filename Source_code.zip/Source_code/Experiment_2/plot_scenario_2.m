
load('i_ELM_ACCURACY_current.mat')
m_acc=mean(ACCURACY); %  mean accuracy for floating point.


load('i_ELM_ACCURACY_current_round_reg.mat')
accuracy_reg=mean(ACCURACY,2); % mean regression


load('i_ELM_ACCURACY_current_ga_reg_ini.mat')
accuracy_reg_ga=mean(ACCURACY,2); % mean regression


load('i_ELM_ACCURACY_current_ga_no_ini.mat')
accuracy_rand_ga=mean(ACCURACY,2); % mean regression


figure()
hold on; box on;

plot(m_acc*ones(1,31) ,'k', 'LineWidth', 2)

plot(accuracy_reg, 'r--', 'LineWidth', 2)

plot(accuracy_reg_ga, 'b-.', 'LineWidth', 2)

plot(accuracy_rand_ga, 'g:', 'LineWidth', 2)



ylim([0.5,0.82])
xlim([1,15])
xticks(1:2:15)

xlabel('Integer range') 
ylabel('Accuracy of the proposed approach')

grid on;
set(gca,'FontSize',18) 

legend({'Real-valued readout (baseline)', 'Quantized readout', 'GA initialized with the quantized readout', 'GA initialized randomly' },'Location','southeast' )  







