clear all

%RVFL with density based encoding
clear all
DATA_EXTRACT_iELM_search % hyperparameters search
clear all
DATA_EXTRACT_iELM_parameters % Extracts best parameters
clear all
DATA_EXTRACT_iELM_accuracy % uses hyperparameters to obtain accuracy
clear all
DATA_EXTRACT_iELM_accuracy_round_reg % uses hyperparameters to obtain accuracy when regression solution is rounded
clear all
DATA_EXTRACT_iELM_accuracy_ga_ini % uses hyperparameters to obtain accuracy when GA is initialized with the quantized regression solution
clear all
DATA_EXTRACT_iELM_accuracy_ga_no_ini % uses hyperparameters to obtain accuracy when GA is initialized randomly


%Plot results
clear all
plot_scenario_2
